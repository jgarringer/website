/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package maze;

/**
 *
 * @author James
 */
public class MazeTester 
{
    public static void main(String[] args) 
    {
        Maze test = new Maze(11, 11, "111111111111000001000110100010101e0100000"
                + "10110111110101101010001011000101000111111010001101b1010001100"
                + "0001000111111111111");
        
        test.solve();
    }
}
